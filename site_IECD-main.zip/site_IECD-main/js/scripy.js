
// scrow presciso para os indices
function smoothScroll(event, targetSelector, offset = 0) {
    event.preventDefault();
    const target = document.querySelector(targetSelector);
    if (target) {
      const targetPosition = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  }

// faz o fechamento automatico do menu nav quando um link é clicado
document.addEventListener('DOMContentLoaded', function () {
    const navbarToggler = document.querySelector('.navbar-toggler'); // Botão para abrir/fechar o menu
    const navbarCollapse = document.querySelector('.navbar-collapse'); // Menu colapsável

    // Seleciona todos os links dentro do menu que não acionam dropdowns
    const navLinks = document.querySelectorAll(
        '.navbar-collapse .nav-link:not(.dropdown-toggle), .navbar-collapse .dropdown-item'
    );

    // Adiciona o evento de clique para recolher o menu
    navLinks.forEach(link => {
        link.addEventListener('click', function () {
            // Recolhe o menu se estiver visível
            if (navbarCollapse.classList.contains('show')) {
                navbarToggler.click();
            }
        });
    });
});


if (window.innerWidth >= 700) {
   // monta cusros MBA PC
document.addEventListener("DOMContentLoaded", async () => {
    const boxCardPc = document.getElementById("box-card-pc-mba");

    try {
        const response = await fetch("./js/mba.json");
        const data = await response.json();

     

        if (data.length > 0) {
            // Adicione o cabeçalho apenas uma vez
            const cabecalhoCurso = `
                <div class="col-12 p-0">
                    <div class="my-3">
                        <div class="etiqueta d-flex justify-content-start align-items-center">
                            <p class="table-header ch-1 m-0">Curso</p>
                            <p class="table-header ch-2 m-0">Duração</p>
                            <p class="table-header ch-3 m-0">Investimento</p>
                            <p class="table-header ch-4 m-0">Carga horária</p>
                            <p class="table-header ch-5 m-0">Início</p>
                        </div>
                    </div>
                </div>
            `;
            boxCardPc.innerHTML = cabecalhoCurso;

            // Adicione os cursos
            data.forEach(curso => {
                const cursoHTML = `
                    <div class="my-3">
                        <div class="etiquetaCurso d-flex justify-content-start align-items-center">
                            <div class="table-curso cc-1">
                                <h4>${curso.curso}</h4>
                            </div>
                            <p class="table-curso cc-2 m-0">${curso.duracao}</p>
                            <p class="table-curso cc-3 m-0">${curso.investimento}</p>
                            <p class="table-curso cc-4 m-0">${curso.carga_horaria}</p>
                            <p class="table-curso cc-5 m-0">${curso.inicio}</p>
                            <p class="table-curso cc-6 d-flex justify-content-end align-items-center m-0">
                                <button 
                                    class="btn btn-primary btn-saiba-mais" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#cursoModal" 
                                    data-curso="${curso.curso}"
                                    data-sobre="${curso.sobre}"
                                    >
                                    SAIBA MAIS
                                </button>
                            </p>
                        </div>
                    </div>
                `;
                boxCardPc.innerHTML += cursoHTML;
            });
        }
    } catch (error) {
        console.error("Erro ao carregar os cursos:", error);
    }
});

// monta cusros Posgrad PC
document.addEventListener("DOMContentLoaded", async () => {
    const boxCardPc = document.getElementById("box-card-pc-pos-grad");

    try {
        const response = await fetch("./js/posgrad.json");
        const data = await response.json();



        if (data.length > 0) {
            // Adicione o cabeçalho apenas uma vez
            const cabecalhoCurso = `
                <div class="col-12 p-0">
                    <div class="my-3">
                        <div class="etiqueta d-flex justify-content-start align-items-center">
                            <p class="table-header ch-1 m-0">Curso</p>
                            <p class="table-header ch-2 m-0">Duração</p>
                            <p class="table-header ch-3 m-0">Investimento</p>
                            <p class="table-header ch-4 m-0">Carga horária</p>
                            <p class="table-header ch-5 m-0">Início</p>
                        </div>
                    </div>
                </div>
            `;
            boxCardPc.innerHTML = cabecalhoCurso;

            // Adicione os cursos
            data.forEach(curso => {
                const cursoHTML = `
                    <div class="my-3">
                        <div class="etiquetaCurso d-flex justify-content-start align-items-center">
                            <div class="table-curso cc-1">
                                <h4>${curso.curso}</h4>
                            </div>
                            <p class="table-curso cc-2 m-0">${curso.duracao}</p>
                            <p class="table-curso cc-3 m-0">${curso.investimento}</p>
                            <p class="table-curso cc-4 m-0">${curso.carga_horaria}</p>
                            <p class="table-curso cc-5 m-0">${curso.inicio}</p>
                            <p class="table-curso cc-6 d-flex justify-content-end align-items-center m-0">
                                <button 
                                    class="btn btn-primary btn-saiba-mais" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#cursoModal" 
                                    data-curso="${curso.curso}"
                                    data-sobre="${curso.sobre}"
                                    >
                                    SAIBA MAIS
                                </button>
                            </p>
                        </div>
                    </div>
                `;
                boxCardPc.innerHTML += cursoHTML;
            });
        }
    } catch (error) {
        console.error("Erro ao carregar os cursos:", error);
    }
});

// monta cursos graduaça pc
document.addEventListener("DOMContentLoaded", async () => {
    const boxCardPc = document.getElementById("box-card-pc-grad");
    
   
    
  
    try {
        const response = await fetch("./js/graduacao.json");
        const data = await response.json();
  
        if (data.length > 0) {
            for (let i = 0; i < data.length; i++) {
             
                // Pegando a chave dinâmica do objeto em data[i]
                const chave = Object.keys(data[i])[0];
  
                // Construindo o cabeçalho do curso
                const cabecalhoCurso = `
                    <div class="col-12 section-header-curso d-flex justify-content-between align-items-center mb-2 p-0">
                        <div class="d-flex">
                            <div class="quadrado-verde d-flex justify-content-center align-items-center">
                                <img src="/imagens/left.png" alt="">
                            </div>
                            <h4 id="${chave}" >${data[i][chave][0].curso}</h4>
                        </div>
                      <button 
                          class="btn-curso m-2" 
                          onclick="window.open('https://api.whatsapp.com/send?phone=5551999680031&text=' + encodeURIComponent('Olá! Gostaria de saber mais sobre os cursos de ${data[i][chave][0].curso}.'), '_blank')">
                          SAIBA MAIS
                      </button>
  
  
                    </div>
  
                    <div class="col-12 p-0">
                        <div class="my-3">
                            <div class="etiqueta d-flex justify-content-start align-items-center">
                                <p class="table-header ch-1 m-0">Curso</p>
                                <p class="table-header ch-2 m-0">Duração</p>
                                <p class="table-header ch-3 m-0">Investimento</p>
                                <p class="table-header ch-4 m-0">Carga horária</p>
                                <p class="table-header ch-5 m-0">Início</p>
                            </div>
                        </div>
                    </div>
                `;
  
                boxCardPc.innerHTML += cabecalhoCurso;
                
                // Pegando os cursos
                const cursos = data[i][chave];
                
                // Loop para adicionar os cursos
                cursos.slice(1).forEach(curso => {
                    const cursoHTML = `
                        <div class="my-3">
                            <div class="etiquetaCurso d-flex justify-content-start align-items-center">
                                <div class="table-curso cc-1">
                                    <h4>${curso.curso}</h4>
                                </div>
                                <p class="table-curso cc-2 m-0">${curso.duracao}</p>
                                <p class="table-curso cc-3 m-0">${curso.investimento}</p>
                                <p class="table-curso cc-4 m-0">${curso.carga_horaria}</p>
                                <p class="table-curso cc-5 m-0">${curso.inicio}</p>
                                <p class="table-curso cc-6 d-flex justify-content-end align-items-center m-0">
                                    <button 
                                        class="btn btn-primary btn-saiba-mais" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#cursoModal" 
                                        data-curso="${curso.curso}"
                                        data-sobre="${curso.sobre}"
                                        >
                                        SAIBA MAIS
                                    </button>
                                </p>
                            </div>
                        </div>
                    `;
                    boxCardPc.innerHTML += cursoHTML;
                });
  
            }
        }
  
    } catch (error) {
        console.error("Erro ao carregar os cursos:", error);
    }
  
  });
}else{

    // monta Pos MBA Cel
document.addEventListener("DOMContentLoaded", async () => {
    const boxCardCel = document.getElementById("box-card-cel-mba");

    try {
        const response = await fetch("./js/mba.json");
        const data = await response.json();

       

        if (data.length > 0) {
            data.forEach(curso => {
                const cursoHTML = `
                    <div class="my-3">
                        <div class="cardCurso">
                            <div class="d-flex flex-column">
                                <div class="text-center m-0 box-curso p-4 pt-5">
                                    <h4 class="text-uppercase ">${curso.curso}</h4>
                                </div>
                                <div class="box-curso">
                                    <div class="d-flex justify-content-between align-items-center text-center">
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-regular fa-hourglass" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Duração</p>
                                            <p>${curso.duracao}</p>
                                        </div>
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-solid fa-money-check-dollar" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Investimento</p>
                                            <p>${curso.investimento}</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center text-center pb-3">
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-regular fa-clock" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Carga horária</p>
                                            <p>${curso.carga_horaria}</p>
                                        </div>
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-regular fa-calendar-check" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Início</p>
                                            <p>${curso.inicio}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end mx-2 mb-2 text-center">
                               <button 
                                    class="btn btn-primary btn-saiba-mais-cel" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#cursoModal" 
                                    data-curso="${curso.curso}"
                                    data-sobre="${curso.sobre}"
                                    >
                                    SAIBA MAIS
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                boxCardCel.innerHTML += cursoHTML;
            });
        }
    } catch (error) {
        console.error("Erro ao carregar os cursos:", error);
    }
});

// monta Pos grad Cel
document.addEventListener("DOMContentLoaded", async () => {
    const boxCardCel = document.getElementById("box-card-cel-pos-grad");

    try {
        const response = await fetch("./js/posgrad.json");
        const data = await response.json();

        

        if (data.length > 0) {
            data.forEach(curso => {
                const cursoHTML = `
                    <div class="my-3">
                        <div class="cardCurso">
                            <div class="d-flex flex-column">
                                <div class="text-center m-0 box-curso p-4 pt-5">
                                    <h4 class="text-uppercase ">${curso.curso}</h4>
                                </div>
                                <div class="box-curso">
                                    <div class="d-flex justify-content-between align-items-center text-center">
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-regular fa-hourglass" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Duração</p>
                                            <p>${curso.duracao}</p>
                                        </div>
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-solid fa-money-check-dollar" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Investimento</p>
                                            <p>${curso.investimento}</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center text-center pb-3">
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-regular fa-clock" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Carga horária</p>
                                            <p>${curso.carga_horaria}</p>
                                        </div>
                                        <div class="box-text-cursos-Cel">
                                            <i class="fa-regular fa-calendar-check" style="font-size: 24px; margin-bottom: 10px;"></i>
                                            <p class="tagcel b1">Início</p>
                                            <p>${curso.inicio}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end mx-2 mb-2 text-center">
                               <button 
                                    class="btn btn-primary btn-saiba-mais-cel" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#cursoModal" 
                                    data-curso="${curso.curso}"
                                    data-sobre="${curso.sobre}"
                                    >
                                    SAIBA MAIS
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                boxCardCel.innerHTML += cursoHTML;
            });
        }
    } catch (error) {
        console.error("Erro ao carregar os cursos:", error);
    }
});

// monta cursos graduação cel
document.addEventListener("DOMContentLoaded", async () => {
  const boxCardCel = document.getElementById("box-card-cel-grad");

  try {
      const response = await fetch("./js/graduacao.json");
      const data = await response.json();

      if (data.length > 0) {
          for (let i = 0; i < data.length; i++) {

              // Pegando a chave dinâmica do objeto em data[i]
              const chave = Object.keys(data[i])[0];

              // Construindo o cabeçalho do curso para box-card-cel
              const cabecalhoCursoCel = `
                  <div id="${chave}" class="col-12 section-header-curso d-flex justify-content-between align-items-center mb-1 p-0">
                      <div class="d-flex">
                          <div class="quadrado-verde d-flex justify-content-center align-items-center">
                              <img src="/imagens/left.png" alt="">
                          </div>
                          <div class="d-flex justify-content-center align-items-center text-center" >
                            <h4  class="p-0">${data[i][chave][0].curso}</h4>
                          </div>

                      </div>
                    <button 
                        class="btn-curso m-2" 
                        onclick="window.open('https://api.whatsapp.com/send?phone=5551999680031&text=' + encodeURIComponent('Olá! Gostaria de saber mais sobre os cursos de ${data[i][chave][0].curso}.'), '_blank')">
                        SAIBA MAIS
                    </button>
                  </div>
              `;

              boxCardCel.innerHTML += cabecalhoCursoCel;

              // Pegando os cursos
              const cursos = data[i][chave];

              // Loop para adicionar os cursos no box-card-cel
              cursos.slice(1).forEach(curso => {
                  const cursoHTML = `
                      <div class="my-3">
                          <div class="cardCurso">
                              <div class="d-flex flex-column">
                                  <div class="text-center m-0 box-curso p-4 pt-5">
                                      <h4 class="text-uppercase ">${curso.curso}</h4>
                                  </div>
                                  <div class="box-curso">
                                      <div class="d-flex justify-content-between align-items-center text-center">
                                          <div class="box-text-cursos-Cel">
                                              <i class="fa-regular fa-hourglass" style="font-size: 24px; margin-bottom: 10px;"></i>
                                              <p class="tagcel b1">Duração</p>
                                              <p>${curso.duracao}</p>
                                          </div>
                                          <div class="box-text-cursos-Cel">
                                              <i class="fa-solid fa-money-check-dollar" style="font-size: 24px; margin-bottom: 10px;"></i>
                                              <p class="tagcel b1">Investimento</p>
                                              <p>${curso.investimento}</p>
                                          </div>
                                      </div>
                                      <div class="d-flex justify-content-between align-items-center text-center pb-3">
                                          <div class="box-text-cursos-Cel">
                                              <i class="fa-regular fa-clock" style="font-size: 24px; margin-bottom: 10px;"></i>
                                              <p class="tagcel b1">Carga horária</p>
                                              <p>${curso.carga_horaria}</p>
                                          </div>
                                          <div class="box-text-cursos-Cel">
                                              <i class="fa-regular fa-calendar-check" style="font-size: 24px; margin-bottom: 10px;"></i>
                                              <p class="tagcel b1">Início</p>
                                              <p>${curso.inicio}</p>
                                          </div>
                                      </div>
                                  </div>
                              </div>

                              <div class="d-flex justify-content-end mx-2 mb-2 text-center">
                                 <button 
                                      class="btn btn-primary btn-saiba-mais-cel" 
                                      data-bs-toggle="modal" 
                                      data-bs-target="#cursoModal" 
                                      data-curso="${curso.curso}"
                                      data-sobre="${curso.sobre}"
                                      >
                                      SAIBA MAIS
                                  </button>
                              </div>
                          </div>
                      </div>
                  `;
                  boxCardCel.innerHTML += cursoHTML;
              });

          }

      }
  } catch (error) {
      console.error("Erro ao carregar os cursos:", error);
  }

});

}










// Evento para atualizar o modal com o nome do curso
const cursoModal = document.getElementById("cursoModal");
cursoModal.addEventListener("show.bs.modal", (event) => {
    const button = event.relatedTarget;
    const cursoNome = button.getAttribute("data-curso");
    const cursoSobre = button.getAttribute("data-sobre");

    const modalCursoNome = document.getElementById("modalCursoNome");
    modalCursoNome.textContent = cursoNome;

    const modalCursoDetalhe = document.getElementById("modalCursoDetalhe");
    modalCursoDetalhe.textContent = cursoSobre;

});


// Carocel dinamico
const swiper = new Swiper('.swiper', {
    // Optional parameters
    direction: 'horizontal',
    loop: true,
  
  
    // Navigation arrows
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },

    slidesPerView: 3,
    spaceBetween: 30,
  
    breakpoints: {
      // when window width is >= 320px
      320: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      // when window width is >= 480px
      480: {
        slidesPerView: 1,
        spaceBetween: 30
      },
      // when window width is >= 640px
      640: {
        slidesPerView: 3,
        spaceBetween: 40
      }
    }

  });

